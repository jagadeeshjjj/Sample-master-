sap.ui.define([
	"zprs/maintainTV/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("zprs.maintainTV.controller.App", {
		onInit: function() {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		}
	});
});