sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"zprs/maintainTV/controller/BaseController",
	"zprs/maintainTV/Services/MatterServices",
	"sap/m/Token",
	"sap/ui/model/Sorter",
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/Label',
	'sap/m/Text',
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(JSONModel, MessageToast, BaseController, MatterServices, Token, Sorter, Button, Dialog, Label, Text, DateFormat, Filter) {
	"use strict";
	return BaseController.extend("zprs.maintainTV.controller.Home", {

		onInit: function() {
			//--Getting View instance
			var oView = this.getView();

			var that = this;
			//--Core Model
			this.maintainTableModel = new JSONModel({
				"title": "MaintainTableView",
				"settings": {
					"isEdit": false,
					"isPanelShow": true,
					"isTableShow": false
				},
				"MatterDetails": {},
				"columnsSelected": {
					"Counter": false,
					"DocumentNumber": false,
					"Fieldlength18": false,
					"SourceCOItem": false,
					"ParentDBItem": false,
					"UserName": false,
					"TimeStamp": false,
					"ErrorFlag": false,
					"ErrorMessage": false,
					"Postingrow": false
				}
			});
			     
			oView.setModel(this.maintainTableModel, "maintainTableModel");

			//--Table Model setting to Core Model
			var tableModel = new JSONModel();
			tableModel.loadData((jQuery.sap.getModulePath("zprs.maintainTV", "/config/products.json")));
			tableModel.attachRequestSent(function() {});
			tableModel.attachRequestCompleted(function() {
				that.maintainTableModel.setProperty("/MatterDetails", tableModel.getData());
			});

			//-- New Columns model Popup data setup
			var newColumnsModel = this.onGetNewColumnsModel();
			oView.setModel(newColumnsModel);

		},
		onGetNewColumnsModel: function() {
			var oModel = new JSONModel();
			jQuery.ajax(jQuery.sap.getModulePath("zprs.maintainTV", "/config/ColumnSelection.json"), {
				dataType: "json",
				success: function(oData) {
					oModel.setData(oData);
				},
				error: function() {
					jQuery.sap.log.error("failed to load json");
				}
			});
			return oModel;
		},

		handleSelectDialogPress: function(oEvent) {
			//debugger;
			//	var oEvent.getParameters().selectedIndex
			//--Allow only on restrict mode
			if (oEvent.getParameters().selectedIndex != 1) {
				return;
			}
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("zprs.maintainTV.fragment.Dialog", this);
				this._oDialog.setModel(this.getView().getModel());
			}

			// Multi-select if required
			var bMultiSelect = !!oEvent.getSource().data("multi");
			this._oDialog.setMultiSelect(bMultiSelect);

			// Remember selections if required
			var bRemember = !!oEvent.getSource().data("remember");
			this._oDialog.setRememberSelections(bRemember);

			// clear the old search filter
			//	this._oDialog.getBinding("items").filter([]);

			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();

		},

		handleSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Name", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		handleClose: function(oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var selectedStr = aContexts.map(function(oContext) {
				return oContext.getObject().Name;
			}).join(",");

			if (aContexts && aContexts.length) {
				MessageToast.show("You have chosen " + aContexts.map(function(oContext) {
					return oContext.getObject().Name;
				}).join(", "));
			} else {
				MessageToast.show("No new item was selected.");
			}
			//	oEvent.getSource().getBinding("items").filter([]);
			//	debugger;
			this.selectedColumnsArr = selectedStr.split(",");
			var leng = this.selectedColumnsArr.length;
			for (var i = 0; i < leng; i++) {
				this.maintainTableModel.setProperty("/columnsSelected/" + this.selectedColumnsArr[i].replace(/ /g,""), true);
			}
			//this.maintainTableModel.setProperty("/columnsSelected/Counter", true);
		},
		//--Table display mode handling
		handleDisplayMode: function(oEvent) {
			//	debugger;
			this.maintainTableModel.setProperty("/settings/isEdit", false);
			this.maintainTableModel.setProperty("/settings/isTableShow", true);
			this.maintainTableModel.setProperty("/settings/isPanelShow", false);
		},
		//--Table mintain [EDIT] mode handling
		handleMaintainMode: function(oEvent) {
			//	debugger;
			this.maintainTableModel.setProperty("/settings/isTableShow", true);
			this.maintainTableModel.setProperty("/settings/isEdit", true);
			this.maintainTableModel.setProperty("/settings/isPanelShow", false);
			this.aProductCollection = jQuery.extend(true, [], this.maintainTableModel.getProperty("/MatterDetails/ProductCollection"));
		},
		onSave: function(oEvent) {
			//	this.maintainTableModel.setProperty("/settings/isEdit", false);
		},
		onCancel: function(oEvent) {
			//debugger;
			//	this.maintainTableModel.setProperty("/settings/isEdit", true);
			this.maintainTableModel.setProperty("/MatterDetails/ProductCollection", this.aProductCollection);
			this.rebindTable(this.oReadOnlyTemplate, "Navigation");

		},
		rebindTable: function(oTemplate, sKeyboardMode) {
			this.oTable.bindItems({
				path: "maintainTableModel>/MatterDetails/ProductCollection",
				template: oTemplate,
				key: "ProductId"
			}).setKeyboardMode(sKeyboardMode);
		},

		//---Adding new row to table
		onAddNewRow: function(oEvent) {
			var tempArr = this.maintainTableModel.getProperty("/MatterDetails").ProductCollection;
			tempArr.unshift({
				"ProductId": "",
				"Category": "",
				"MainCategory": "",
				"TaxTarifCode": "",
				"SupplierName": "",
				"WeightMeasure": 0,
				"WeightUnit": "",
				"Description": "",
				"Name": "",
				"DateOfSale": "",
				"ProductPicUrl": "",
				"Status": "",
				"Quantity": 0,
				"UoM": "PC",
				"CurrencyCode": "",
				"Price": 0,
				"Width": 0,
				"Depth": 0,
				"Height": 0,
				"DimUnit": ""
			});
			this.maintainTableModel.refresh(); //which will add the new record

		}

	});
});